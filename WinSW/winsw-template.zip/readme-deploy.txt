
// Set XML parameters
// Install as a service
> intecmar-coptool-web install

// Start service.
> intecmar-coptool-web start
